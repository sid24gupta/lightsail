from django.apps import AppConfig


class SecondApplicationConfig(AppConfig):
    name = 'second_application'
